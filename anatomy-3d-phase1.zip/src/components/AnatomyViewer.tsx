import { Canvas } from '@react-three/fiber'
import { Environment, OrbitControls, ContactShadows, Html } from '@react-three/drei'
import { Suspense, useState } from 'react'
import * as THREE from 'three'

function AnatomicalPlaceholder({ onSelect }: { onSelect: (name: string) => void }) {
  const [hovered, setHovered] = useState('')
  const material = (color: string) => new THREE.MeshStandardMaterial({ color, roughness: 0.55, metalness: 0.02 })
  const skin = material('#c98f79')
  const bone = material('#e8dfca')
  const muscle = material('#a94f54')
  const joint = material('#d8b8a0')
  const selectProps = (name: string) => ({
    onClick: (event: any) => { event.stopPropagation(); onSelect(name) },
    onPointerOver: (event: any) => { event.stopPropagation(); setHovered(name); document.body.style.cursor = 'pointer' },
    onPointerOut: () => { setHovered(''); document.body.style.cursor = 'auto' },
  })

  return (
    <group position={[0, -0.15, 0]}>
      {/* Stylized educational placeholder assembled from primitives; replace with licensed segmented GLB anatomy assets in later phases. */}
      <mesh position={[0, 1.55, 0]} material={skin} {...selectProps('Skull')}><sphereGeometry args={[0.25, 32, 32]} /></mesh>
      <mesh position={[0, 1.15, 0]} material={bone} {...selectProps('Cervical spine')}><cylinderGeometry args={[0.075, 0.075, 0.55, 16]} /></mesh>
      <mesh position={[0, 0.58, 0]} material={muscle} {...selectProps('Thoracic region')}><capsuleGeometry args={[0.29, 0.55, 8, 20]} /></mesh>
      <mesh position={[0, -0.03, 0]} material={skin} {...selectProps('Abdominal region')}><capsuleGeometry args={[0.25, 0.45, 8, 20]} /></mesh>
      <mesh position={[0, -0.42, 0]} material={joint} {...selectProps('Pelvis')}><sphereGeometry args={[0.31, 24, 16]} scale={[1, 0.62, 0.7]} /></mesh>
      {[-1, 1].map((side) => (
        <group key={side}>
          <mesh position={[side * 0.43, 0.72, 0]} rotation={[0, 0, side * -0.22]} material={bone} {...selectProps('Upper limb')}><capsuleGeometry args={[0.09, 0.55, 6, 12]} /></mesh>
          <mesh position={[side * 0.59, 0.15, 0]} rotation={[0, 0, side * -0.12]} material={skin} {...selectProps('Forearm')}><capsuleGeometry args={[0.075, 0.48, 6, 12]} /></mesh>
          <mesh position={[side * 0.16, -0.96, 0]} material={bone} {...selectProps('Femur')}><capsuleGeometry args={[0.105, 0.78, 6, 12]} /></mesh>
          <mesh position={[side * 0.16, -1.68, 0]} material={skin} {...selectProps('Lower leg')}><capsuleGeometry args={[0.085, 0.58, 6, 12]} /></mesh>
        </group>
      ))}
      {hovered && <Html position={[0.48, 1.7, 0]} distanceFactor={7}><div className="model-tooltip">{hovered}</div></Html>}
    </group>
  )
}

export default function AnatomyViewer({ selected, onSelect }: { selected: string; onSelect: (name: string) => void }) {
  return (
    <div className="viewer-canvas">
      <Canvas camera={{ position: [3.4, 1.8, 5.4], fov: 38 }} dpr={[1, 1.7]}>
        <color attach="background" args={['#0a1524']} />
        <ambientLight intensity={1.3} />
        <directionalLight position={[4, 6, 5]} intensity={2.3} />
        <directionalLight position={[-4, 1, -3]} intensity={1.1} color="#6e9ecb" />
        <Suspense fallback={<Html center><div className="loading-label">Loading anatomy scene…</div></Html>}>
          <AnatomicalPlaceholder onSelect={onSelect} />
          <ContactShadows position={[0, -2.1, 0]} opacity={0.35} scale={5} blur={2.5} />
          <Environment preset="city" />
        </Suspense>
        <OrbitControls makeDefault enableDamping dampingFactor={0.08} minDistance={2.8} maxDistance={9} target={[0, 0, 0]} />
      </Canvas>
      <div className="viewer-disclaimer">PHASE 1 PROTOTYPE · stylized interaction placeholder, not an anatomically accurate model</div>
      <div className="viewer-selection">Selected: <strong>{selected}</strong></div>
    </div>
  )
}
