import { useMemo, useState } from 'react'
import {
  Activity, Atom, BookOpen, Brain, ChevronDown, ChevronRight, CircleHelp,
  Expand, Eye, HeartPulse, Layers3, Menu, RotateCcw, Search, Settings2,
  ShieldCheck, Sparkles, Stethoscope, UserRound, X, ZoomIn
} from 'lucide-react'
import AnatomyViewer from './components/AnatomyViewer'
import { anatomySystems } from './data/systems'

const icons: Record<string, typeof Activity> = {
  overview: UserRound, skeletal: Activity, muscular: Activity, nervous: Brain,
  cardiovascular: HeartPulse, respiratory: Activity, digestive: Activity,
  urinary: Activity, endocrine: Atom, lymphatic: Activity, reproductive: Activity,
  integumentary: Layers3,
}

export default function App() {
  const [activeSystem, setActiveSystem] = useState('overview')
  const [selectedStructure, setSelectedStructure] = useState('Human Body')
  const [search, setSearch] = useState('')
  const [mobileMenu, setMobileMenu] = useState(false)
  const [layers, setLayers] = useState({ surface: true, skeletal: true, muscular: true, organs: true, vessels: false, nerves: false })
  const current = useMemo(() => anatomySystems.find(s => s.id === activeSystem) ?? anatomySystems[0], [activeSystem])
  const filtered = anatomySystems.filter(s => `${s.name} ${s.arabic}`.toLowerCase().includes(search.toLowerCase()))

  const chooseSystem = (id: string) => {
    setActiveSystem(id)
    const system = anatomySystems.find(s => s.id === id)
    setSelectedStructure(system?.name ?? 'Human Body')
    setMobileMenu(false)
  }

  return (
    <div className="app-shell">
      <aside className={`sidebar ${mobileMenu ? 'sidebar-open' : ''}`}>
        <div className="brand">
          <div className="brand-mark"><Atom size={23} /></div>
          <div><div className="brand-name">ANATOMY<span>3D</span></div><div className="brand-subtitle">INTERACTIVE MEDICAL ATLAS</div></div>
          <button className="icon-button mobile-close" onClick={() => setMobileMenu(false)} aria-label="Close menu"><X size={18}/></button>
        </div>
        <div className="sidebar-label">WORKSPACE</div>
        <button className="nav-item active"><Layers3 size={17}/> Anatomy Explorer</button>
        <button className="nav-item"><BookOpen size={17}/> Learning Library <span className="soon">SOON</span></button>
        <button className="nav-item"><Sparkles size={17}/> AI Anatomy Tutor <span className="soon">SOON</span></button>
        <div className="sidebar-label systems-label">HUMAN BODY SYSTEMS <span>11</span></div>
        <div className="system-search"><Search size={15}/><input value={search} onChange={e => setSearch(e.target.value)} placeholder="Search systems…" /></div>
        <div className="system-list">
          {filtered.map(system => {
            const Icon = icons[system.id] ?? Activity
            return <button key={system.id} className={`system-item ${activeSystem === system.id ? 'selected' : ''}`} onClick={() => chooseSystem(system.id)}>
              <Icon size={17}/><span>{system.name}</span>{activeSystem === system.id ? <ChevronDown size={15}/> : <ChevronRight size={15}/>}
            </button>
          })}
          {filtered.length === 0 && <div className="empty-search">No systems found.</div>}
        </div>
        <div className="sidebar-bottom">
          <div className="profile-avatar">A</div>
          <div className="profile-copy"><strong>Guest workspace</strong><span>Local preview</span></div>
          <Settings2 size={17} className="muted-icon"/>
        </div>
      </aside>

      {mobileMenu && <button className="mobile-scrim" aria-label="Close navigation" onClick={() => setMobileMenu(false)} />}

      <main className="main-content">
        <header className="topbar">
          <div className="topbar-left">
            <button className="icon-button menu-trigger" onClick={() => setMobileMenu(true)} aria-label="Open menu"><Menu size={20}/></button>
            <div><div className="breadcrumb">ANATOMY LIBRARY <ChevronRight size={13}/> <strong>{current.name.toUpperCase()}</strong></div><div className="page-title">3D Anatomy Explorer</div></div>
          </div>
          <div className="topbar-actions">
            <div className="language-pill">EN <span>·</span> AR</div>
            <button className="icon-button" title="Help"><CircleHelp size={18}/></button>
            <div className="user-chip"><div className="user-dot">G</div><span>Guest</span></div>
          </div>
        </header>

        <section className="content-area">
          <div className="intro-row">
            <div><div className="eyebrow"><span className="live-dot"/> INTERACTIVE ANATOMY WORKSPACE</div><h1>{current.name}</h1><p>{current.description}</p></div>
            <div className="level-tag"><ShieldCheck size={15}/> SPECIALIST TRACK</div>
          </div>

          <div className="workspace-grid">
            <section className="viewer-card">
              <div className="viewer-header"><div><span className="section-kicker">3D MODEL VIEWER</span><h2>{current.name}</h2></div><div className="viewer-header-actions"><button className="small-icon" title="Reset view" onClick={() => setSelectedStructure(current.name)}><RotateCcw size={16}/></button><button className="small-icon" title="Fullscreen"><Expand size={16}/></button></div></div>
              <AnatomyViewer selected={selectedStructure} onSelect={setSelectedStructure}/>
              <div className="viewer-controls"><span><span className="control-key">DRAG</span> Rotate</span><span><span className="control-key">SCROLL</span> Zoom</span><span><span className="control-key">CLICK</span> Select structure</span><div className="control-actions"><button className="small-icon"><ZoomIn size={16}/></button><button className="small-icon"><RotateCcw size={16}/></button></div></div>
            </section>

            <aside className="details-column">
              <section className="panel-card selected-panel">
                <div className="panel-heading"><div><span className="section-kicker">ANATOMICAL CONTEXT</span><h3>Structure Details</h3></div><span className="status-dot"/></div>
                <div className="structure-name">{selectedStructure}</div>
                <div className="structure-type">Human anatomy · {current.name}</div>
                <div className="detail-placeholder"><Eye size={19}/><span>Choose a structure in the 3D viewer to inspect its anatomical profile.</span></div>
                <div className="detail-list"><div><span>System</span><strong>{current.name}</strong></div><div><span>Arabic</span><strong>{current.arabic}</strong></div><div><span>Content status</span><strong className="status-planned">{current.status === 'interface' ? 'Prototype' : 'Planned'}</strong></div></div>
              </section>

              <section className="panel-card">
                <div className="panel-heading"><div><span className="section-kicker">VISUALIZATION</span><h3>Anatomical Layers</h3></div><Layers3 size={18} className="panel-icon"/></div>
                <div className="layer-list">
                  {Object.entries(layers).map(([key, value]) => <label className="layer-row" key={key}><span className={`layer-swatch ${key}`}/><span className="layer-name">{key.charAt(0).toUpperCase() + key.slice(1)}</span><input type="checkbox" checked={value} onChange={() => setLayers(prev => ({...prev, [key]: !prev[key as keyof typeof prev]}))}/></label>)}
                </div>
                <div className="layer-note">Layer toggles are UI scaffolding in Phase 1. They will control segmented anatomical assets in Phase 2.</div>
              </section>

              <section className="ai-card">
                <div className="ai-heading"><div className="ai-icon"><Sparkles size={17}/></div><div><strong>AI Anatomy Tutor</strong><span>Context-aware learning assistant</span></div><span className="coming-tag">PHASE 5</span></div>
                <p>Ask questions about the selected anatomical structure and explore clinically relevant concepts.</p>
                <button className="ai-button" disabled>AI tutor integration coming later <ChevronRight size={15}/></button>
              </section>
            </aside>
          </div>

          <section className="structures-section">
            <div className="section-header"><div><span className="section-kicker">EXPLORE CONTENT</span><h2>Key structures</h2></div><span className="content-count">{current.structures.length} TOPICS</span></div>
            <div className="structure-grid">{current.structures.map((name, index) => <button className={`structure-card ${selectedStructure === name ? 'active-structure' : ''}`} key={name} onClick={() => setSelectedStructure(name)}><span className="structure-index">{String(index + 1).padStart(2, '0')}</span><span>{name}</span><ChevronRight size={15}/></button>)}</div>
          </section>
          <footer><span>ANATOMY 3D · PHASE 1 FOUNDATION</span><span>Educational prototype · Not for clinical diagnosis</span></footer>
        </section>
      </main>
    </div>
  )
}
