export type AnatomySystem = {
  id: string
  name: string
  arabic: string
  description: string
  structures: string[]
  status: 'interface' | 'content-planned'
}

export const anatomySystems: AnatomySystem[] = [
  { id: 'overview', name: 'Human Body Overview', arabic: 'نظرة عامة على الجسم', description: 'Explore the major anatomical regions and body organization.', structures: ['Head and neck', 'Thorax', 'Abdomen', 'Pelvis', 'Upper limb', 'Lower limb'], status: 'interface' },
  { id: 'skeletal', name: 'Skeletal System', arabic: 'الجهاز الهيكلي', description: 'Bones, joints, cartilage and skeletal landmarks.', structures: ['Axial skeleton', 'Appendicular skeleton', 'Joints', 'Ligaments'], status: 'content-planned' },
  { id: 'muscular', name: 'Muscular System', arabic: 'الجهاز العضلي', description: 'Skeletal, smooth and cardiac muscle anatomy.', structures: ['Muscle groups', 'Origins and insertions', 'Tendons', 'Fascia'], status: 'content-planned' },
  { id: 'nervous', name: 'Nervous System', arabic: 'الجهاز العصبي', description: 'Central, peripheral and autonomic nervous systems.', structures: ['Brain', 'Spinal cord', 'Cranial nerves', 'Peripheral nerves'], status: 'content-planned' },
  { id: 'cardiovascular', name: 'Cardiovascular System', arabic: 'الجهاز القلبي الوعائي', description: 'Heart, blood vessels and circulation.', structures: ['Heart', 'Arteries', 'Veins', 'Capillaries'], status: 'content-planned' },
  { id: 'respiratory', name: 'Respiratory System', arabic: 'الجهاز التنفسي', description: 'Airways, lungs, pleura and gas-exchange structures.', structures: ['Nasal cavity', 'Trachea', 'Bronchi', 'Lungs', 'Alveoli'], status: 'content-planned' },
  { id: 'digestive', name: 'Digestive System', arabic: 'الجهاز الهضمي', description: 'Gastrointestinal tract and accessory digestive organs.', structures: ['Esophagus', 'Stomach', 'Intestines', 'Liver', 'Pancreas'], status: 'content-planned' },
  { id: 'urinary', name: 'Urinary System', arabic: 'الجهاز البولي', description: 'Kidneys, urinary passages and bladder.', structures: ['Kidneys', 'Ureters', 'Urinary bladder', 'Urethra'], status: 'content-planned' },
  { id: 'endocrine', name: 'Endocrine System', arabic: 'جهاز الغدد الصماء', description: 'Hormone-producing glands and endocrine tissues.', structures: ['Pituitary', 'Thyroid', 'Adrenals', 'Pancreatic islets'], status: 'content-planned' },
  { id: 'lymphatic', name: 'Lymphatic System', arabic: 'الجهاز اللمفاوي', description: 'Lymphatic vessels, nodes and lymphoid organs.', structures: ['Lymph nodes', 'Spleen', 'Thymus', 'Lymphatic ducts'], status: 'content-planned' },
  { id: 'reproductive', name: 'Reproductive System', arabic: 'الجهاز التناسلي', description: 'Male and female reproductive anatomy.', structures: ['Male anatomy', 'Female anatomy', 'Gonads', 'Reproductive ducts'], status: 'content-planned' },
  { id: 'integumentary', name: 'Integumentary System', arabic: 'الجهاز اللحافي', description: 'Skin and associated structures.', structures: ['Epidermis', 'Dermis', 'Hair', 'Nails', 'Glands'], status: 'content-planned' },
]
